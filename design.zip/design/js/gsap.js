gsap.registerPlugin(ScrollTrigger);

gsap.from(".center-img", {
  y: -200,
  duration: 0.8,
  delay: 0.2,
  scrub: true,
  opacity: 0,
  stagger: 0.5,

  scrollTrigger: {
    trigger: ".slider",
  },
});

// ---------------------small to large----------------------
gsap.from(".back-sec1", {
  scrollTrigger: {
    trigger: ".sec6",
    scrub: true,
    start: "-40% bottom",
    end: "-10% top",
  },
  scaleX: 0,
  transformOrigin: "left center",
  ease: "none",
});

//   ----------------------up-down-------------------------------
const growT8 = gsap.timeline({
  scrollTrigger: {
    trigger: ".sec2",
    scrub: 1.5,
    start: "-45% center",
    end: "+=400",
    ease: "Bounce.easeOut",
  },
});
growT8.to(".center-img img", {
  y: -100,
  duration: 2,
  delay: 0.2,
});

//   ----------------------up-scale-down-------------------------------
const growT6 = gsap.timeline({
  scrollTrigger: {
    trigger: ".sec7",
    scrub: 1.3,
    start: "10% center",
    end: "+=400",
    ease: "Bounce.easeOut",
  },
});
growT6.to(".sec7-img5 img", {
  duration: 1,
  scale: 1.5,
});
