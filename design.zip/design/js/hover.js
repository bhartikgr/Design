let text = document.querySelector(".round");

let animation = gsap.to(".round", {
  paused: true,
  ease: "Bounce.easeOut",
  y: 90,
  x: 50,
  duration: 1.5,
  delay: 0.1,
  stagger: 0.5,
});

text.addEventListener("mouseenter", () => animation.play());
text.addEventListener("mouseleave", () => animation.reverse());
